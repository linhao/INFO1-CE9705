package edu.nyu.scps.buttonpress;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ButtonPressActivity extends Activity implements View.OnClickListener {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		//findViewById can't come before setContentView.
		Button button1 = (Button)findViewById(R.id.button1);
		button1.setOnClickListener(this);        
		
		Button button2 = (Button)findViewById(R.id.button2);
		button2.setOnClickListener(this);    
    }
    
	@Override
	public void onClick(View v) {
		//((Button)v).setText("Thank you for pressing this button.");
		switch(v.getId()) {
		case R.id.button1:
			((Button)v).setText(ButtonPressActivity.this.getString(R.string.after_pressone));
			break;
		
		case R.id.button2:
			((Button)v).setText(ButtonPressActivity.this.getString(R.string.after_presstwo));
			break;
		}
		
		Toast.makeText(ButtonPressActivity.this, "Thank you for clicking!",
			Toast.LENGTH_SHORT).show();
	}
    
    
}