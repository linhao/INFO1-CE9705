package edu.nyu.scps.widgetthread;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class WidgetThreadActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
 
       final TextView textView = (TextView)findViewById(R.id.textView);       	       
       final Handler handler = new Handler() {
			@Override
			public void handleMessage(Message message) {
				textView.setText(String.format("%d", message.arg1));	
			}
		};
		
		final MyThread myThread = new MyThread(handler);
		myThread.start();
		
		//Configure the button
		final Button button = (Button)findViewById(R.id.button);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(WidgetThreadActivity.this, "Thanks for clicking...It will count till 50!", Toast.LENGTH_LONG).show();		
				button.setBackgroundColor(0x80ff0000);		
			}
		});
    }
}    

final class MyThread extends Thread 
{
	final Handler handler;
	
	MyThread(Handler handler) 
	{
		this.handler = handler;
	}
       
	@Override
	public void run() 
	{
		for (int i = 1; i <=50; i++) 
		{
			try {
				//1000 milliseconds == 1 second
				Thread.sleep(1000);
				} 
			catch (InterruptedException e) 
			{
				Log.e("ERROR", "Thread Interrupted");
			}
 
			final Message message = handler.obtainMessage(); //Get an empty Message.
				message.arg1 = i;
				//Send the message to the Handler.
				//Calls handleMessage, below.
				handler.sendMessage(message);
		}	
	}
}