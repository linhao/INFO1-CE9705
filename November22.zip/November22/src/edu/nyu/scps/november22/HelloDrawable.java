package edu.nyu.scps.november22;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;


//Taken from class Example
public class HelloDrawable extends Drawable {
	final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

	public HelloDrawable() {
		super();
		final int width = 100;
		final int height = width/3;
		setBounds(0, 0, width, height);
		paint.setTextSize(width * 15 / 100);
	}

	@Override
	public void draw(Canvas canvas) {
		paint.setColor(Color.RED);
		final Rect rect = getBounds();
		canvas.drawRect(rect, paint);

		paint.setColor(Color.BLACK);
		canvas.drawText("Got 27 Rings??", rect.left, rect.bottom, paint);
		
	}

	@Override
	public int getOpacity() {
		return PixelFormat.OPAQUE;
	}

	@Override
	public void setAlpha(int alpha) {
	}

	@Override
	public void setColorFilter(ColorFilter colorFilter) {
	}

}
