package edu.nyu.scps.november22;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

// Try to improve upon November16; take helloDrawable from Nov 15 example
// When Yankee logo is pressed, say "Yes, winners, going for 28"
// When redsox log is pressed, say "Nope, losers"
// When pressed anywhere else, say "Got 27 Rings?"

public class YankeeView extends View {
	
//	private Drawable yanks, bosox;
	private final HelloDrawable helloDrawable = new HelloDrawable();
	private PointF p = new PointF();	//center of drawable
	
	Context context;
	
	public YankeeView(Context context) {
		super(context);
		this.context = context;
//		yanks = context.getResources().getDrawable(R.drawable.nyy1335);
//		bosox = context.getResources().getDrawable(R.drawable.bosox);
		
		//Upper left corner of drawable is initially
		//at upper left corner of view.
		final Rect b = helloDrawable.getBounds();
		p.set(
			(b.right - b.left) / 2.0f,
			(b.bottom - b.top) / 2.0f
		);

		setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch(event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					//Put the center of the drawable where the finger touched.
					p.set(event.getX(), event.getY());
					invalidate();	//calls onDraw
					return true;
				default:
					return false;
				}
			}
		});
	}
	
	@Override	
	protected void onDraw(Canvas canvas){
		final int width = getWidth();
		final int height = getHeight();
		
		//canvas.drawColor(Color.WHITE);	//background 
		setBackgroundResource(R.drawable.ic_launcher);
			
		//draw yankees logo
		final Resources resources = context.getResources();
		final Bitmap bitMap = BitmapFactory.decodeResource(resources, R.drawable.nyy1335);
		//final Bitmap bitMap2 = BitmapFactory.decodeResource(resources, R.drawable.got27);
		final Bitmap bitMap3 = BitmapFactory.decodeResource(resources, R.drawable.bosox);

		canvas.drawBitmap(bitMap, width/4, height/4, null);
		//canvas.drawBitmap(bitMap2, width/2, height/3, null);	
		canvas.drawBitmap(bitMap3, width/4, height/2, null);
		
		final Rect b = helloDrawable.getBounds();

		//Put center of drawable at p.
		canvas.translate(
			p.x - (b.right - b.left) / 2.0f,
			p.y - (b.bottom - b.top) / 2.0f
		);
		helloDrawable.draw(canvas);				
	}	
}
