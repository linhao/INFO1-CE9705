package edu.nyu.scps.december20;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;
import edu.nyu.scps.hellogridview.R;

public class December20Activity extends Activity {
    /** Called when the activity is first created. */
	// Use the grid example from the android developer site as a starting point
	// upon clicking on the grid icon, the background color will change
	// background to red or magenta if team will not make playoffs; green if yes
	// each team will get a toast commentary
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        GridView gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(new ImageAdapter(this));

        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
            		// better to use an array for next time of this stuff
            		if (position == 0)
            		{
            			Toast.makeText(December20Activity.this, "YES, But Rex, SHUT UP!!!" + "",  Toast.LENGTH_SHORT).show();
            			v.setBackgroundColor(Color.GREEN);
            			//ImageView image = (ImageView) findViewById(R.id.gridview);
            					//findViewById(R.id.icon_image);
            			//image.setImageResource(R.drawable.nyy);
            		}
            		
            		if (position == 1)
            		{
            			v.setBackgroundColor(Color.RED);
            			Toast.makeText(December20Activity.this, "Nah! Should have kept Haynesworth!" + "",  Toast.LENGTH_SHORT).show();
            		}
            		
            		if (position == 2)
            		{
            			v.setBackgroundColor(Color.RED);
            			Toast.makeText(December20Activity.this, "Don't think so.  Just win baby; but not this year!" + "",  Toast.LENGTH_SHORT).show();
            		}
            		
            		if (position == 3)
            		{
            			v.setBackgroundColor(Color.GRAY);
            			Toast.makeText(December20Activity.this, "Maybe, I hope...Don't Choke Again" + "",  Toast.LENGTH_SHORT).show();
            		}
            		
            		if (position == 4)
            		{
            			v.setBackgroundColor(Color.RED);
            			Toast.makeText(December20Activity.this, "NO! Suh, don't stomp on your team!" + "",  Toast.LENGTH_SHORT).show();
            		}
            		
            		if (position == 5)
            		{
            			v.setBackgroundColor(Color.GREEN);
            			Toast.makeText(December20Activity.this, "Pretty much in...Yeah Dirty Birds!" + "",  Toast.LENGTH_SHORT).show();
            		}
            		
            		if (position == 6)
            		{
            			v.setBackgroundColor(Color.MAGENTA);
            			Toast.makeText(December20Activity.this, "NO! Philip Rivers boasts and then loses..." + "",  Toast.LENGTH_SHORT).show();
            		}
            		
            		if (position == 7)
            		{
            			v.setBackgroundColor(Color.RED);
            			Toast.makeText(December20Activity.this, "NO!  Dream Team? More like nightmare..." + "",  Toast.LENGTH_SHORT).show();
            		}
            		
            		if (position == 8)
            		{
            			v.setBackgroundColor(Color.RED);
            			Toast.makeText(December20Activity.this, "NO! Still alive...but too injured" + "",  Toast.LENGTH_SHORT).show();
            		} 	
            }
        });
    }
    
    public class ImageAdapter extends BaseAdapter {
        private Context mContext;

        public ImageAdapter(Context c) {
            mContext = c;
        }

        public int getCount() {
            return mThumbIds.length;
        }

        public Object getItem(int position) {
            return null;
        }

        public long getItemId(int position) {
            return 0;
        }

        // create a new ImageView for each item referenced by the Adapter
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            
            if (convertView == null) {  // if it's not recycled, initialize some attributes
                imageView = new ImageView(mContext);
                imageView.setLayoutParams(new GridView.LayoutParams(85, 85));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setPadding(8, 8, 8, 8);
                imageView.setBackgroundColor(Color.WHITE);
            } else {
                imageView = (ImageView) convertView;
            }
                        
            imageView.setImageResource(mThumbIds[position]);
            return imageView;
        }
        
        // references to team icons
        private Integer[] mThumbIds = {
                R.drawable.nyj, R.drawable.titans,
                R.drawable.oak, R.drawable.nyg,
                R.drawable.lions, R.drawable.atl,
                R.drawable.sd, R.drawable.phi,
                R.drawable.cin
        };        
   }
}