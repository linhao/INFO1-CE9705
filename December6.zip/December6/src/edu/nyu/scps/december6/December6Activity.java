package edu.nyu.scps.december6;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class December6Activity extends Activity {
	static final int LIST_DIALOG_ID = 0;
	
    /** Called when the activity is first created. */
	// Using default android api
	// select from a list of baseball teams, change logo
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
    	final Button button = (Button)findViewById(R.id.button);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				showDialog(LIST_DIALOG_ID);
			}
		});      
    }
    
	@Override
	protected Dialog onCreateDialog(int id, Bundle bundle) {
		final TextView textView = (TextView)findViewById(R.id.textView);
		final String[ ] items = {"Yankees", "Red Sox", "Cubs", "Mets"};

		switch (id) {
			case LIST_DIALOG_ID:
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setIconAttribute(android.R.attr.alertDialogIcon);
			builder.setTitle("List of Baseball Teams");

			builder.setItems(items, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int team) {
					ImageView image = (ImageView) findViewById(R.id.icons);
					
					if (items[team] == "Yankees") {	
						//ImageView image = (ImageView) findViewById(R.id.icons);
						//Bitmap bMap = BitmapFactory.decodeResource(getResources(), R.drawable.nyy1335);				
						image.setImageResource(R.drawable.nyy);
						
						textView.setText("Great Choice! " + items[team] + " have 27 Championships!");
						Toast.makeText(December6Activity.this, "Best Baseball Team EVER!", Toast.LENGTH_LONG).show();
					}
					if (items[team] == "Red Sox") {
						image.setImageResource(R.drawable.bosox);
						//ImageView image = (ImageView) findViewById(R.id.icons);
						//Bitmap bMap = BitmapFactory.decodeResource(getResources(), R.drawable.bosox);				
						//image.setImageBitmap(bMap);
						
						textView.setText("Pathetic. " + items[team] + " are Chokers Galore");
						Toast.makeText(December6Activity.this, "Red Sux Nation Crashes Again!", Toast.LENGTH_LONG).show();
					}
					if (items[team] == "Cubs") {
						image.setImageResource(R.drawable.cubs);
						
						Toast.makeText(December6Activity.this, "Why even bother?  100 Years and still waiting...", Toast.LENGTH_LONG).show();
						textView.setText("WTF? " + items[team] + " got nothing since 1908");						
					}
					if (items[team] == "Mets") {
						image.setImageResource(R.drawable.mets);
						
						textView.setText("So sad. " + items[team] + " --- step child of NYC");
						Toast.makeText(December6Activity.this, "What are you thinking for NYC?  Too many choices???", Toast.LENGTH_LONG).show();
				}	
			}
		});

			return builder.create();

			default:
			return null;
		}
	}
}