package edu.nyu.scps.december13;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class December13Activity extends Activity {
    /** Called when the activity is first created. */
	// Generate a menu from Android API
	// When menu is clicked, logo on top changes and new text
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.yankees:           	
              //  ImageView image = (ImageView) findViewById(R.id.yankees);
            	//image.setImageResource(R.drawable.nyy);
            	startActivity(new Intent(this, Yankees.class));
            	Toast.makeText(this, "Go Yankees!...Press back button", Toast.LENGTH_LONG).show();
            	break;
            case R.id.mets: 
            	Toast.makeText(this, "Mets are so-so...Press back button", Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, Mets.class));
            	break;
        }
        return true;
	};	
}